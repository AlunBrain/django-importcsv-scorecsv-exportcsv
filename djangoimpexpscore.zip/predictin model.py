# -*- coding: utf-8 -*-
"""
Created on Mon Aug 17 19:25:52 2020

@author: ab7800
"""

#pip install django-computedfields
#pip install graphviz

import pandas as pd
import numpy as np
from sklearn.metrics import accuracy_score, confusion_matrix

import warnings
from collections import Counter
warnings.filterwarnings('ignore')
import seaborn as sns
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split 
from sklearn.preprocessing import StandardScaler 
from sklearn.svm import SVC 
from sklearn.preprocessing import MinMaxScaler
import pickle 
import joblib

df = pd.read_csv('C:\\django\\creating an app tensorflow\\bankloan.csv')
df=df.dropna()    # removes roes with any missing data
df.isna().any()
df=df.drop('Loan_ID', axis=1)

df['LoanAmount'] = (df['LoanAmount'] *1000).astype(int)   # convert loand into 1000 as an integer

Counter(df['Loan_Status'])


def ohevalue(df):
    ohe_col=joblib.load("C:/djanoloan2svm/DjangoAPI/MyAPI/allcol.pkl")
    cat_columns=['Gender','Married','Education','Self_Employed','Property_Area']
    df_processed = pd.get_dummies(df, columns=cat_columns)
    newdict={}
    for i in ohe_col:
        if i in df_processed.columns:
            newdict[i]=df_processed[i].values
        else:
            newdict[i]=0
    newdf=pd.DataFrame(newdict)
    return newdf

dfs=df

df=dfs

boom=ohevalue(df)

mdl=joblib.load("C:/djanoloan2svm/DjangoAPI/MyAPI/loan_model.pkl")
scalers=joblib.load("C:/djanoloan2svm/DjangoAPI/MyAPI/scaler.pkl")


X_train = scalers.fit_transform(boom) 

y_pred = mdl.predict_proba(X_train)







X=scalers.transform(boom) 

y_pred= pd.DataFrame(mdl.predict(X).astype(decimal))

format(mdl.predict(X), '.4f')

#me from here
newdf=pd.DataFrame(y_pred)

float(mdl.predict(X))


answer=approvereject(boom)[0]

Xscalers=approvereject(boom)[1]

				#answer=approvereject(ohevalue(df))[0]
				#Xscalers=approvereject(ohevalue(df))[1]



def approvereject(unit):
    try:

        mdl=joblib.load("C:/djanoloan2svm/DjangoAPI/MyAPI/loan_model.pkl")
        scalers=joblib.load("C:/djanoloan2svm/DjangoAPI/MyAPI/scaler.pkl")
        X=scalers.transform(unit) 
        y_pred=mdl.predict(X)
        #me from here
        newdf=pd.DataFrame(y_pred)


        #old
       #y_pred=(y_pred>0.58)
       # newdf=pd.DataFrame(y_pred, columns=['Status'])
       # newdf=newdf.replace({True:'Approved', False:'Rejected'})
        return (newdf.values[0][0],X[0])
    except ValueError as e:
        return (e.args[0])