from import_export import resources
from .models import Approvals

class ApprovalResource(resources.ModelResource):
    class Meta:
        model = Approvals