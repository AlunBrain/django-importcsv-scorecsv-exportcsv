
from django.shortcuts import render
from django.http import HttpResponse
from tablib import Dataset

from django.shortcuts import redirect
from .resources import ApprovalResource
from .models import Approvals


from sklearn.svm import SVC 

from django.shortcuts import render
from rest_framework import viewsets
from django.core import serializers
from rest_framework.response import Response
from rest_framework import status
#from . forms import ApprovalForm
from django.http import HttpResponse
from django.http import JsonResponse
from django.contrib import messages
from . serializers import approvalsSerializers
import pickle
#from keras import backend as K
import joblib
import numpy as np
from sklearn import preprocessing
import pandas as pd
from collections import defaultdict, Counter
from django.db import transaction


def home_view(request):
    return render(request, 'base.html')

def export_data(request):
    if request.method == 'POST':
        file_format = request.POST['file-format']
        approval_resource = ApprovalResource()
        dataset = approval_resource.export()
        if file_format == 'CSV':
            response = HttpResponse(dataset.csv, content_type='text/csv')
            response['Content-Disposition'] = 'attachment; filename="exported_data.csv"'
            return response        
        elif file_format == 'JSON':
            response = HttpResponse(dataset.json, content_type='application/json')
            response['Content-Disposition'] = 'attachment; filename="exported_data.json"'
            return response
        elif file_format == 'XLS (Excel)':
            response = HttpResponse(dataset.xls, content_type='application/vnd.ms-excel')
            response['Content-Disposition'] = 'attachment; filename="exported_data.xls"'
            return response   
   # Employee.objects.all().delete()
    return render(request, 'export.html')

def import_data(request):
    if request.method == 'POST':
        file_format = request.POST['file-format']
        approval_resource = ApprovalResource()
        dataset = Dataset()
        new_apps = request.FILES['importData']

        if file_format == 'CSV':
            imported_data = dataset.load(new_apps.read().decode('utf-8'),format='csv')
            result = approval_resource.import_data(dataset, dry_run=True)
        elif file_format == 'JSON':
            imported_data = dataset.load(new_apps.read().decode('utf-8'),format='json')
            result = approval_resource.import_data(dataset, dry_run=True)
            
        if not result.has_errors():
            approval_resource.import_data(dataset, dry_run=False)

    return render(request, 'import.html')    

def del_data(request):
    if request.method == 'POST':
        Approvals.objects.all().delete()
    return render(request, 'del_data.html')     





#t = TemperatureData.objects.get(id=1)
#t.value = 999
#t.save(['value'])


class ApprovalsView(viewsets.ModelViewSet):
    queryset = Approvals.objects.all()
    serializer_class = approvalsSerializers
        

def ohevalue(df):
    ohe_col=joblib.load("C:/djanoloan2svm/DjangoAPI/MyAPI/allcol.pkl")
    cat_columns=['Gender','Married','Education','Self_Employed','Property_Area']
    df_processed = pd.get_dummies(df, columns=cat_columns)
    newdict={}
    for i in ohe_col:
        if i in df_processed.columns:
            newdict[i]=df_processed[i].values
        else:
            newdict[i]=0
    newdf=pd.DataFrame(newdict)
    return newdf


def approvereject(unit):
    try:

        mdl=joblib.load("C:/djanoloan2svm/DjangoAPI/MyAPI/loan_model.pkl")
        scalers=joblib.load("C:/djanoloan2svm/DjangoAPI/MyAPI/scaler.pkl")
        X=scalers.transform(unit) 
        y_pred=mdl.predict(X)
        #me from here
        newdf=pd.DataFrame(y_pred)


        #old
       #y_pred=(y_pred>0.58)
       # newdf=pd.DataFrame(y_pred, columns=['Status'])
       # newdf=newdf.replace({True:'Approved', False:'Rejected'})
        return (newdf.values[0][0],X[0])
    except ValueError as e:
        return (e.args[0])

#https://www.youtube.com/watch?v=L8zCIUij0C8
def update_data(request):

    mdl=joblib.load("C:/djanoloan2svm/DjangoAPI/MyAPI/loan_model.pkl")
    scalers=joblib.load("C:/djanoloan2svm/DjangoAPI/MyAPI/scaler.pkl")

    if request.method == 'POST':
 
        df=Approvals.objects.all().values()  #dictionary form
     #   df1 = Approvals.objects.all().values_list() # in a tuple
        data1 = pd.DataFrame(df)  # this gets column names
     #   data2 = pd.DataFrame(df1) # does not get col names

        boom=ohevalue(data1)
    #    print(boom)

        X_train = scalers.fit_transform(boom) 
        answeri = mdl.predict(X_train)
        answer = answeri *1.0001
        dfx =data1[['Loan_ID']]

        dfx['pred'] = answer

        print(dfx)

        #answer=approvereject(ohevalue(df))[0]
       
        

        with transaction.atomic():
            for i, row in dfx.iterrows():
                mv = Approvals.objects.get(Loan_ID=row.Loan_ID)


                mv.value = row.pred

                mv.save()

      #  answerx=109.99
       # Approvals.objects.update(value=answerx)
         #Xscalers=approvereject(ohevalue(df))[1]
    return render(request, 'update_data.html')    




