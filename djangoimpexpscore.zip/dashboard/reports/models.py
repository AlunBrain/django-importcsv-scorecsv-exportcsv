
from django.db import models

# Create your models here.

class Approvals(models.Model):
	Loan_ID=models.CharField(max_length=15)
	Gender=models.CharField(max_length=15)
	Married=models.CharField(max_length=15)
	Dependents=models.IntegerField()
	Education=models.CharField(max_length=15)
	Self_Employed=models.CharField(max_length=15)
	ApplicantIncome=models.IntegerField()
	CoapplicantIncome=models.IntegerField()
	LoanAmount=models.IntegerField()
	Loan_Amount_Term=models.IntegerField()
	Credit_History=models.IntegerField()
	Property_Area=models.CharField(max_length=15)
	value = models.FloatField(null=True)


	def valuex(self):
		"Returns blah."
		if self.LoanAmount<100:
			return 100
		elif self.LoanAmount<200:
			return 200
		else:
			return 300
	valboom=property(valuex)

	def _get_full_name(self):
		"Returns the person's full name."
		return u'%s %s' % (self.Gender, self.Married)
	Gendmar = property(_get_full_name)

	def __str__(self):
		return self.Loan_ID

						
