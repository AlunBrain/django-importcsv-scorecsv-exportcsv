from import_export.admin import ImportExportModelAdmin
from django.contrib import admin
from .models import Approvals

#admin.site.register(Approvals)


@admin.register(Approvals)
class ApprovalAdmin(ImportExportModelAdmin):
    pass